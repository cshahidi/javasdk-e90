import java.io.File;
import java.util.ArrayList;
import java.util.Hashtable;

import com.amazonaws.services.simpledb.model.ReplaceableAttribute;

public class main
{
	public static void problem1(S3Utils s3Utils, String suffix)
	{
		// PROBLEM 1
		s3Utils.createFolder("someFolder", suffix);
	}

	public static void problem2(S3Utils s3Utils)
	{
		// PROBLEM 2
		s3Utils.deleteBucketContents();
	}

	public static void problem3(S3Utils s3Utils, String suffix,
			String[] filePaths, String[] keys, File[] files,
			Hashtable<String, File> table, String[] folderNames,
			String[] httpaddress)
	{
		// PROBLEM 3

		// Populate our files
		for (int i = 0; i < files.length; i++)
		{
			filePaths[i] = "./src/" + keys[i];
			final File file = new File(filePaths[i]);
			files[i] = file;
			// do not download for indeces higher than five as there
			// is nothing to download
			if (i < 5)
			{
				try
				{
					s3Utils.downloadImage(httpaddress[i], keys[i]);
				}
				catch (Exception e)
				{
					System.out.println("no more downloading required");
					continue;
				}
			}
			table.put(keys[i], files[i]);
		}
		// create the bucket
		s3Utils.createBucket();
		// create the folders
		for (int i = 0; i < folderNames.length; i++)
		{
			s3Utils.createFolder(folderNames[i], suffix);
		}
		// populate the folders
		for (int i = 0; i < table.size(); i++)
		{

			if (i < 2)
			{
				s3Utils.uploadFile(folderNames[2] + "/" + keys[i],
						table.get(keys[i]));
			}
			else if (i < 5)
			{
				s3Utils.uploadFile(folderNames[4] + "/" + keys[i],
						table.get(keys[i]));
			}
			else if (i < 7)
			{
				s3Utils.uploadFile(folderNames[3] + "/" + keys[i],
						table.get(keys[i]));
			}
			else if (i < 10)
			{
				s3Utils.uploadFile(folderNames[5] + "/" + keys[i],
						table.get(keys[i]));
			}
		}
	}

	public static void main(String[] args)
	{
		final String bucketName = "trialbucket-09876";
		final String suffix = "/";
		final String domainName = "newDomain";
		String[] folderNames =
		{
				"stars", "nobel", "stars/images", "stars/resumes",
				"nobel/images", "nobel/resumes"
		};
		String[] picAndTxtFiles =
		{
				"jolie.jpg", "allen.jpg", "pauling.jpg", "feynman.jpg",
				"neruda.jpg", "jolie.txt", "allen.txt", "pauling.txt",
				"feynman.txt", "neruda.txt"
		};
		String[] stars =
		{
				"Angelina Jolie", "Woody Allen"
		};
		String[] nobelists =
		{
				"Linus Pauling", "Richard Feynman", "Pablo Neruda"
		};
		String[] httpaddress =
		{
				"http://lissarankin.com/wp-content/uploads/2013/05/angelina-jolie.jpg",
				"http://foglobe.com/data_images/main/woody-allen/woody-allen-01.jpg",
				"http://upload.wikimedia.org/wikipedia/commons/5/58/L_Pauling.jpg",
				"http://upload.wikimedia.org/wikipedia/en/4/42/Richard_Feynman_Nobel.jpg",
				"http://upload.wikimedia.org/wikipedia/commons/0/04/Pablo_Neruda.jpg"
		};

		String[] filePaths = new String[picAndTxtFiles.length];
		File[] files = new File[picAndTxtFiles.length];
		Hashtable<String, File> table = new Hashtable<String, File>();
		final ArrayList<ReplaceableAttribute> attributesA = new ArrayList<ReplaceableAttribute>();
		final ArrayList<ReplaceableAttribute> attributesW = new ArrayList<ReplaceableAttribute>();
		final ArrayList<ReplaceableAttribute> attributesP = new ArrayList<ReplaceableAttribute>();
		final ArrayList<ReplaceableAttribute> attributesF = new ArrayList<ReplaceableAttribute>();
		final ArrayList<ReplaceableAttribute> attributesN = new ArrayList<ReplaceableAttribute>();

		final String bucketUrl = "https://s3.amazonaws.com/" + bucketName;
		S3Utils s3Utils = new S3Utils(bucketName);
		SDBUtils sDBUtils = new SDBUtils();

		final String[] starProperties =
		{
				"Full Name", "Picture URL", "Resume URL", "Most Popular Movie"
		};
		final String[][] starPropertyValues =
		{
				{// Angelina
						stars[0],
						bucketUrl + folderNames[2] + suffix + picAndTxtFiles[0],
						bucketUrl + suffix + folderNames[3] + suffix
								+ picAndTxtFiles[5], "Mr and Mrs Smith"
				},
				{// Woody
						stars[1],
						bucketUrl + folderNames[2] + suffix + picAndTxtFiles[1],
						bucketUrl + suffix + folderNames[3] + suffix
								+ picAndTxtFiles[6], "Manhattan"
				}
		};
		final String[] nobelistProperties =
		{
				"Full Name", "Picture URL", "Resume URL", "Most Popular Book",
				"Nobel Year", "Field of Nobel"
		};
		final String[][] nobelistPropertyValues =
		{
				{
						// PAULING
						nobelists[0],
						bucketUrl + folderNames[4] + suffix + picAndTxtFiles[2],
						bucketUrl + suffix + folderNames[5] + suffix
								+ picAndTxtFiles[7],
						"Linus Pauling and the Golden Pistacchio",
						"1954 & 1962", "Chemistry & Peace"
				},
				{
						// FEYNMAN
						nobelists[1],
						bucketUrl + folderNames[4] + suffix + picAndTxtFiles[3],
						bucketUrl + suffix + folderNames[5] + suffix
								+ picAndTxtFiles[8],
						"Surely Your Joking Mr Feynman", "1965", "Physics"
				},
				{
						// NERUDA
						nobelists[2],
						bucketUrl + folderNames[4] + suffix + picAndTxtFiles[4],
						bucketUrl + suffix + folderNames[5] + suffix
								+ picAndTxtFiles[9], "Twenty Love Poems",
						"1971", "Literature"
				}
		};

		for (int i = 0; i < starProperties.length; i++)
		{
			for (int j = 0; j < 2; j++)
			{
				if (j == 0)
				{
					attributesA.add(new ReplaceableAttribute(starProperties[i],
							starPropertyValues[j][i], true));
				}
				else if (j == 1)
				{
					attributesW.add(new ReplaceableAttribute(starProperties[i],
							starPropertyValues[j][i], true));
				}
			}
		}
		for (int i = 0; i < nobelistProperties.length; i++)
		{
			for (int j = 0; j < 3; j++)
			{
				if (j == 0)
				{
					attributesP.add(new ReplaceableAttribute(
							nobelistProperties[i],
							nobelistPropertyValues[j][i], true));
				}
				else if (j == 1)
				{
					attributesF.add(new ReplaceableAttribute(
							nobelistProperties[i],
							nobelistPropertyValues[j][i], true));
				}
				else
				{
					attributesN.add(new ReplaceableAttribute(
							nobelistProperties[i],
							nobelistPropertyValues[j][i], true));
				}
			}
		}
		problem3(s3Utils, suffix, filePaths, picAndTxtFiles, files, table,
				folderNames, httpaddress);
		problem1(s3Utils, suffix);
		problem2(s3Utils);
		String starDomainName = "stars";
		String nobelDomainName = "nobelists";
		sDBUtils.createSDBDomain(starDomainName);
		sDBUtils.createSDBDomain(nobelDomainName);

		sDBUtils.listDomains();
		sDBUtils.putAttributes(stars[0], attributesA, starDomainName);
		sDBUtils.putAttributes(stars[1], attributesW, starDomainName);
		sDBUtils.putAttributes(nobelists[0], attributesP, nobelDomainName);
		sDBUtils.putAttributes(nobelists[1], attributesF, nobelDomainName);
		sDBUtils.putAttributes(nobelists[2], attributesN, nobelDomainName);
		sDBUtils.listDomains();
		cleanup(s3Utils, sDBUtils, starDomainName, nobelDomainName);
	}

	public static void cleanup(S3Utils s3Utils, SDBUtils sDBUtils,
			String starDomainName, String nobelDomainName)
	{
		// recursively delete everything in the bucket prob2
		problem2(s3Utils);
		// delete the bucket
		s3Utils.deleteBucket();
		// Delete all SimpleDB Domains
		sDBUtils.deleteSDBDomain(starDomainName);
		sDBUtils.deleteSDBDomain(nobelDomainName);
	}
}
