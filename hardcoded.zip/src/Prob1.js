var AWS = require('aws-sdk');
var fs = require('fs');
AWS.config.update({
	region : 'us-west-2'
});

// Lists all buckets
var s3 = new AWS.S3();
s3.listBuckets(function(err, data) {
	for ( var index in data.Buckets) {
		var bucket = data.Buckets[index];
		console.log("Bucket: ", bucket.Name, ' : ', bucket.CreationDate);
	}
});

// Create a New Bucket and Object
var s3 = new AWS.S3({
	params : {
		Bucket : 'myBucket',
		Key : 'myKey'
	}
});
s3.createBucket(function() {
	s3.putObject({
		Body : 'Hello!'
	}, function() {
		console.log("Successfully uploaded data to myBucket/myKey");
	});
});

// Upload local file to bucket
fs.readFile(sourceFile, function(err, data) {
	if (err) {
		throw err;
	}

	s3.client.putObject({
		Bucket : bucketName,
		Key : 'Folder/image.jpg',
		Body : data,
		ACL : 'public-read'
	}, function(res) {
		console.log('Successfully uploaded file.');
	});
});
